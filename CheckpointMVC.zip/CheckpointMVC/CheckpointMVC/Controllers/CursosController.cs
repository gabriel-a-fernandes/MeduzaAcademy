﻿using Microsoft.AspNetCore.Mvc;

namespace CheckpointMVC.Controllers
{
    public class CursosController : Controller
    {
        public IActionResult Cursos()
        {
            return View();
        }
    }
}

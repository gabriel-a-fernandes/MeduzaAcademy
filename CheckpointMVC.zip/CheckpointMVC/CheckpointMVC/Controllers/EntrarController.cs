﻿using Microsoft.AspNetCore.Mvc;

namespace CheckpointMVC.Controllers
{
    public class EntrarController : Controller
    {
        public IActionResult Entrar()
        {
            return View();
        }
    }
}
